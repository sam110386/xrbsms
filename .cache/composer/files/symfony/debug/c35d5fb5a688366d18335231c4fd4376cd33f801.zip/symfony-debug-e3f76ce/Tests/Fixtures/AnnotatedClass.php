<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

class AnnotatedClass
{
    /**
     * @deprecated
     */
    public function deprecatedMethod()
    {
    }
}
